package com.dthoperator.service;

import java.util.ArrayList;

import com.dthoperator.bean.RechargeDetails;

public class RechargeCollectionHelper {

	public static ArrayList<RechargeDetails> list;

	static {
		list = new ArrayList<>();

		list.add(new RechargeDetails("Airtel", 1089343431, "Monthly", 210, 4567));
		list.add(new RechargeDetails("DishTV", 303322123, "Yearly", 1260, 2345));
		list.add(new RechargeDetails("Reliance", 892343430, "Quarterly", 650,
				1234));
	}

	public void addRechargeDetails(RechargeDetails rechargeDetails) {

		System.out.println("Adding Details...");

		list.add(rechargeDetails);

	}

	public void displayRechargeDetails(int transactionID) {

		for (RechargeDetails rechargeDetails : list)
			System.out.println(rechargeDetails);
	}
	public ArrayList<RechargeDetails> getAllDetails()
	{
		return list;
		
	}
}
