package com.dthoperator.exception;

public class RechargeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RechargeException() {
		// TODO Auto-generated constructor stub
	}

	public RechargeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
